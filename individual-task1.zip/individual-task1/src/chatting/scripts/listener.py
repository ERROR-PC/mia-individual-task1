#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def topic_callback(msg: String):
    rospy.loginfo(f'topic callback: {msg.data}')

if __name__ == '__main__':
    rospy.init_node('listener')

    subscriber = rospy.Subscriber(
        'chat',
        String,
        callback=topic_callback,
        queue_size=10
    )

    rospy.spin()
